# forc parse-bytecode
