<!-- markdownlint-disable MD041 -->
Here are a list of commands available to forc:
