# Style Guide

## Capitalization

<!-- This section should explain the capitalization style guide -->
<!-- cap:example:start -->
In Sway, structs, traits, and enums are `CapitalCase`. Modules, variables, and functions are `snake_case`, constants are `SCREAMING_SNAKE_CASE`. The compiler will warn you if your capitalization is ever unidiomatic.
<!-- cap:example:end -->
