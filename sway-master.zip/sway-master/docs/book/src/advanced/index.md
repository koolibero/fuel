# Advanced Concepts

Advanced concepts.

- [Advanced Types](./advanced_types.md)
- [Advanced Storage](./advanced_storage.md)
- [Generic Types](./generic_types.md)
- [Traits](./traits.md)
- [Associated Types](./associated_types.md)
- [Generics and Trait Constraints](./generics_and_trait_constraints.md)
- [Assembly](./assembly.md)
- [Never Type](./never_type.md)
