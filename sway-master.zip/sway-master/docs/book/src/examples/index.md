# Example

Some basic example contracts to see how Sway and Forc work.

- [Counter](./counter.md)
- [`FizzBuzz`](./fizzbuzz.md)
- [Wallet Smart Contract](./wallet_smart_contract.md)
- [Liquidity Pool](./wallet_smart_contract.md)

Additional examples can be found in the [Sway Applications](https://github.com/FuelLabs/sway-applications/tree/master) repository.
