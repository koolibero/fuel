# Enums

An enum can be matched on by specifying the name of the enum and the variant.

```sway
{{#include ../../../../../code/language/control_flow/src/lib.sw:complex_enum_match}}
```
