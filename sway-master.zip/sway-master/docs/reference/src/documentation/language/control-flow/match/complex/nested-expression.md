# Nested Expressions

We can nest `match` expressions by placing them inside code blocks.

```sway
{{#include ../../../../../code/language/control_flow/src/lib.sw:nested_enum_match}}
```
