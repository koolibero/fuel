# Constants

Variables can be matched on but only if they are constants.

```sway
{{#include ../../../../../code/language/control_flow/src/lib.sw:complex_constant_match}}
```
