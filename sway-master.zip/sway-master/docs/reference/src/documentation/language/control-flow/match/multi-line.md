# Multi Line Arm

The arm of a `match` expression can contain multiple lines of code by wrapping the right side of the arrow `=>` in brackets `{}`.

```sway
{{#include ../../../../code/language/control_flow/src/lib.sw:multi_line_match}}
```
