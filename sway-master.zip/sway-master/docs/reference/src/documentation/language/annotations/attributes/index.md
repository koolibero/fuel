# Attributes

An attribute is a metadatum which provides some additional functionality.
