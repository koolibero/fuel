# Style Guide

Programming languages have different ways of styling code i.e. how variables, functions, structures etc. are written.

The following snippets present the style guide for writing `Sway`.

> TODO: overview of content
