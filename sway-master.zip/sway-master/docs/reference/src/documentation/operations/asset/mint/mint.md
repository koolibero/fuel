# Mint

To use the function we must import it.

```sway
{{#include ../../../../code/operations/asset_operations/src/lib.sw:mint_import}}
```

To mint some amount of an asset we specify the `amount` that we would like to mint and pass it into the `mint()` function.

```sway
{{#include ../../../../code/operations/asset_operations/src/lib.sw:mint}}
```
