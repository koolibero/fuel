# The Sway Reference

<!-- markdown-link-check-disable -->
This is the technical reference for the Sway programming language. For a prose explanation and introduction to the language, please refer to the [Sway Book](https://fuellabs.github.io/sway/v0.61.1/book/).
<!-- markdown-link-check-enable -->
