# forc-debug

Debugger attachable to FuelVM over a GraphQL API.

## Testing

The automated tests assume that `fuel-core` binary is installed.
