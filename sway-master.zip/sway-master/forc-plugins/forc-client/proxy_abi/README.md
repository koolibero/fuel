# Proxy Contract

This folder contains pre-built version of the owned proxy contract, its abi and `storage-slots.json` file.

*contract url*: [sway-standard-implementation/src-14/owned_proxy](https://github.com/FuelLabs/sway-standard-implementations/tree/174f5ed9c79c23a6aaf5db906fe27ecdb29c22eb).
*commit hash*: `174f5ed9c79c23a6aaf5db906fe27ecdb29c22eb`
*forc version*: `v0.63.6`
*build command*: `forc build --release`
